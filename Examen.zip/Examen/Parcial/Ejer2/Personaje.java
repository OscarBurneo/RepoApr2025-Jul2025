package Examen.Parcial.Ejer2;

public abstract class Personaje {
    public String nombre, arma, habilidad;
     
    abstract public void atacar();
}
