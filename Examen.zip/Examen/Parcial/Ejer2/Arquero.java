package Examen.Parcial.Ejer2;

public class Arquero extends Personaje {
    public String eficArco;

    
    public void atacar(){
        System.out.print("El arquero está atacando con "+(arma));
    }

}
