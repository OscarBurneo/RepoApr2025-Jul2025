package Examen.Parcial.Ejer1;

public class Habitat {
    Animal[] animales;
    Cuidador cuidador;
    String nombre;
    public Habitat(String nombre,Animal[] animales,Cuidador cuidador){
        this.nombre=nombre;
        this.animales=animales;
        this.cuidador=cuidador;
    }

}
